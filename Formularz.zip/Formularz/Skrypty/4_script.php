<?php
 //echo $POST['square']
 echo "<pre>";
  print_r ($_POST);
 echo "</pre>";
 if (!empty($_POST['name']) && !empty($_POST['Figure'])) {
   switch ($_POST['Figure']) {
     case 'kwadrat':
       header('location: ./square.php');
       break;
     case 'prostokat':
       header('location: ./rectangle.php');
       break;
   }
 }
 else {
   ?>
    <script>
        history.back();
    </script>
    <?php
 }
 ?>
