<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Prostokat</title>
  </head>
  <body>
    <h3>Prostokat</h3>
    <form  method="get">
      <input type="text" name="sideA" placeholder="Podaj blok A"><br><br>
      <input type="text" name="sideB" placeholder="Podaj blok B"><br><br>
      <input type="submit" name="button" value="Oblicz"> <br><br>
    </form>

    <?php
      if (isset($_GET['button'])) {

        if (!empty($_GET['sideA']) && !empty($_GET['sideB']))
        {
            $a = str_replace(',','.',$_GET['sideA']);
            $b = str_replace(',','.',$_GET['sideB']);
            $area = $a * $b;
            $circuit = 2 * $a + 2 * $b;
            echo <<<RESULT
                Pole kwadratu wynosi: $area cm<sup>2</sup><br><br>
            RESULT;
            echo <<<RESULT
                Obwod kwadratu wynosi: $circuit cm<sup>2</sup>
            RESULT;
        }
        else {
          echo "wypelnij bok A i B !";
        }
      }
     ?>

  </body>
</html>
