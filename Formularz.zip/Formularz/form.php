<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Figura geometryczna</title>
  </head>
  <body>
    <h3>Figura geometryczna</h3>
    <form class="form" action="./Skrypty/4_script.php" method="post">
      <input type="text" name="name" placeholder="Podaj imię"> <br><br>
      <input type="radio" name="Figure" value="kwadrat">Kwadrat<br><br>
      <input type="radio" name="Figure" value="prostokat">Prostokat<br><br>
      <input type="submit" value="wybierz figure">
    </from>
  </body>
</html>
