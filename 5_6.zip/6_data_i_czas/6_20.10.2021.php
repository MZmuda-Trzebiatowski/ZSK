<?php
  setlocale(LC_ALL, 'Polish');
  echo "dzien-miesiac-rok".date('d-m-y').'<br>';
  echo date('m-d-y').'<br>';
  echo date('d-M-Y').'<br>';
  echo date('d-F-Y').'<br>';

  echo strftime('%B').'<br><br><br>';
  echo date ('g:i:s').'<br><br><br>';
  echo date ('H:i:s').'<br><br><br>';
  echo date ('H:i:sa').'<br><br><br>';


  $date = getdate();
  echo '<pre>';
  print_r($date);
  echo '</pre>';


 ?>

<script type="text/javascript">
  setTimeout(
    ()=>{
    window.location.reload();
  },1000)
</script>
