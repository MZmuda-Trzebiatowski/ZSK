<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      require_once '../function/funkcja.php';
      show();
      echo '<br><br>';
      show1($_POST['name']);
      echo '<br><br>';
      echo stringValidate('z4kolakkkkkk',7);
     ?>
  </body>
</html>
