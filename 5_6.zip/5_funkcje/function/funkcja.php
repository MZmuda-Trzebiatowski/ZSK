<?php
  function show()
  {
    echo "SHOW";
  }
  function show1($name)
  {
    if (empty($name))
    {
      echo 'Nie podales wszystkich danych';
    }
    else echo $name;
  }

  function stringValidate($str, $substr)
  {
    $str = trim($str);
    $str = strtolower($str);
    $str = ucfirst($str);
    return $str;
  }
 ?>
