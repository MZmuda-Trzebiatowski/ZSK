<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Funkcje</title>
  </head>
  <body>
    <h1>DANE UŻYTKOWNIKA</h1>
    <form action="./scripts/skrypt.php" method="post">
      <input type="text" name="name" placeholder="Podaj imię"><br><br>
      <input type="submit" value="wyslij">
    </form>
  </body>
</html>
